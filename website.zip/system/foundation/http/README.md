#### Bahasa Indonesia

Library ini diadaptasi dari [symfony/http-foundation](https://github.com/symfony/http-foundation) v2.1.6.
Symfony Http Foundation dirilis dibawah Lisensi MIT. Lihat file LICENSE untuk lebih detail.

#### English

This library is adapted from [symfony/http-foundation](https://github.com/symfony/http-foundation) v2.1.6.
Symfony Http Foundation is released under the MIT License. See LICENSE file for details.
