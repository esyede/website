#### Bahasa Indonesia

Library ini diadaptasi dari [fzaninotto/faker](https://github.com/fzaninotto/faker) v1.5.0.
Faker dirilis dibawah Lisensi MIT. Lihat file LICENSE untuk lebih detail.

#### English

This library is adapted from [fzaninotto/faker](https://github.com/fzaninotto/faker) v1.5.0.
Faker is released under the MIT License. See LICENSE file for details.
