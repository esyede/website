<?php

defined('DS') or exit('No direct access.');

use System\Event;

/*
|--------------------------------------------------------------------------
| Events
|--------------------------------------------------------------------------
|
| Event memberikan cara yang bagus untuk memecah keterkaitan resource dalam
| aplikasi anda, sehingga kelas, library ataupun plugin tidak akan tercampur
| dan mudah untuk diawasi.
|
*/

// ..
