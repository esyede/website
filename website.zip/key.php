<?php

defined('DS') or exit('No direct script access.');

/*
|--------------------------------------------------------------------------
| Application Key
|--------------------------------------------------------------------------
|
| File ini (key.php) dibuat otomatis oleh rakit. Salin file ini ke tempat
| yang aman karena file ini berisi kunci untuk membuka aplikasi anda.
|
*/

return 'a22a36f4-c988-3c2a-5240-8b2eb9f34316';
