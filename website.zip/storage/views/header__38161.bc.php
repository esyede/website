<!-- Header start -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/png" href="data:;base64,iVBORw0KGgo=">
    <link rel="stylesheet" href="<?php echo e(asset('packages/docs/css/docs.css?v=' . RAKIT_VERSION)) ?>">
    <title>Rakit :: <?php echo e(trans('docs::docs.header.documentation')) ?> ~ <?php echo e($title) ?></title>

    <meta property="og:type" content="website">
    <meta property="og:title" content="Rakit :: <?php echo e(trans('docs::docs.header.documentation')) ?>">
    <meta property="og:description" content="<?php echo e(trans('docs::docs.header.description')) ?>">
    <meta property="og:site_name" content="Rakit :: <?php echo e(trans('docs::docs.header.documentation')) ?>">
</head>
<!-- Header end -->
