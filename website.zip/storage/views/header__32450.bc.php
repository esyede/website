<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rakit :: <?php echo e($page) ?></title>
    <meta name="description" content="Rakit :: <?php echo e(trans('home.hero.slogan')) ?>">
    <link rel="icon" type="image/png" href="data:;base64,iVBORw0KGgo=">
    <link rel="stylesheet" href="<?php echo e(asset('main/css/main.min.css?v=' . RAKIT_VERSION)) ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Rakit :: <?php echo e($page) ?>">
    <meta property="og:description" content="<?php echo e(trans('home.hero.slogan')) ?>">
    <meta property="og:site_name" content="Rakit :: <?php echo e($page) ?>">
</head>
