<?php

defined('DS') or exit('No direct script access.');

return [
    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | Baris - baris bahasa berikut ini digunakan oleh library Paginator untuk
    | membangun link paginasi. Anda bebas mengubahnya sesuai kebutuhan. Jika
    | anda punya cara yang lebih baik, jangan lupa beri tahu kami!
    |
    */

    'previous' => 'Sebelumnya',
    'next' => 'Berikutnya',
];
