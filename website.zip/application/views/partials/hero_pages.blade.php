<div class="container section has-text-centered">
    <div class="columns is-gapless">
        <div class="column is-offset-one-half mt-6">
            <br>
            @yield('pages_title')
        </div>
    </div>
</div>
<div class="divider is-light"></div>
